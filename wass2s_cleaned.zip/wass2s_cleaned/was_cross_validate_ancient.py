"""Legacy cross-validation module (archived).

This module is superseded by :mod:`wass2s.was_cross_validate`, which adds
support for :class:`~wass2s.was_pcr.WAS_PCR` list predictors and additional
model families.  It is kept for reference and backward compatibility only.

Classes
-------
CustomTimeSeriesSplit
    Leave-one-out splitter with a configurable exclusion window to prevent
    temporal data leakage.
WAS_Cross_Validator
    Cross-validation orchestrator for all model families in the WASS2S pipeline.
"""

import numpy as np
import xarray as xr
from tqdm import tqdm
from wass2s.was_linear_models import *
from wass2s.was_eof import *
from wass2s.was_pcr import *
from wass2s.was_cca import *
from wass2s.was_machine_learning import *
from wass2s.was_analog import *
from wass2s.utils import *
from wass2s.was_mme import *


class CustomTimeSeriesSplit:
    """Leave-one-out cross-validator with a symmetric exclusion window.

    For each test year *i*, all years within a window of width
    ``nb_omit + 1`` centred on *i* are excluded from training.  This
    prevents near-neighbour leakage that would arise from correlated
    adjacent years.

    Parameters
    ----------
    n_splits : int
        Number of cross-validation folds (typically equal to the number of
        years in the dataset).
    """

    def __init__(self, n_splits):
        self.n_splits = n_splits

    def split(self, X, nb_omit, y=None, groups=None):
        """Generate (train, test) index pairs for each fold.

        For fold *i*, a symmetric window of size ``nb_omit + 1`` is centred
        on index *i*; all indices outside the window form the training set.

        Parameters
        ----------
        X : array-like
            Sequence whose length determines the number of samples (typically
            the ``T`` coordinate of a DataArray).
        nb_omit : int
            Number of years adjacent to the test year to exclude from
            training on each side.  Must satisfy
            ``nb_omit + 1 <= len(X)``.
        y : array-like, optional
            Ignored; present for scikit-learn compatibility.
        groups : array-like, optional
            Ignored; present for scikit-learn compatibility.

        Yields
        ------
        train_indices : numpy.ndarray
            Integer indices of the training samples for this fold.
        test_indices : numpy.ndarray
            Integer index of the single test sample (shape ``(1,)``).

        Raises
        ------
        ValueError
            If ``nb_omit + 1`` exceeds the number of samples.
        """
        n_samples = len(X)
        indices = np.arange(n_samples)
        n_folds = min(self.n_splits, n_samples)

        window_len = nb_omit + 1
        if window_len > n_samples:
            raise ValueError("nb_omit too large for number of samples")

        for i in range(n_folds):
            start = i - window_len // 2
            if start < 0:
                start = 0
            end = start + window_len
            if end > n_samples:
                end = n_samples
                start = end - window_len

            window_indices = np.arange(start, end)
            train_indices = np.setdiff1d(indices, window_indices)
            test_indices = np.array([i], dtype=int)

            yield train_indices, test_indices

    def get_n_splits(self, X=None, y=None, groups=None):
        """Return the number of cross-validation folds.

        Parameters
        ----------
        X : array-like, optional
            Ignored; present for scikit-learn compatibility.
        y : array-like, optional
            Ignored; present for scikit-learn compatibility.
        groups : array-like, optional
            Ignored; present for scikit-learn compatibility.

        Returns
        -------
        int
            The configured number of splits.
        """
        return self.n_splits


class WAS_Cross_Validator:
    """Cross-validation orchestrator for the WASS2S model pipeline.

    Wraps :class:`CustomTimeSeriesSplit` and dispatches each fold to the
    correct preprocessing and scoring path depending on the model type.
    Deterministic hindcasts and tercile probabilities are assembled over all
    folds and returned as concatenated DataArrays.

    Parameters
    ----------
    n_splits : int
        Number of cross-validation folds.
    nb_omit : int
        Number of years adjacent to each test year to exclude from training
        (passed to :meth:`CustomTimeSeriesSplit.split`).
    """

    def __init__(self, n_splits, nb_omit):
        self.custom_cv = CustomTimeSeriesSplit(n_splits=n_splits)
        self.nb_omit = nb_omit

    def cross_validate(self, model, Predictant, Predictor=None,
                       clim_year_start=None, clim_year_end=None, **model_params):
        """Run leave-one-out cross-validation for a given model.

        Each fold trains the model on all years except the test window and
        generates a deterministic prediction for the held-out year.
        Tercile probabilities are computed from the full hindcast after
        all folds complete.

        Supported model families and their preprocessing:

        - :class:`~wass2s.was_cca.WAS_CCA` — full-series detrend and
          standardize before the fold loop.
        - :class:`~wass2s.was_analog.WAS_Analog` — no predictor required;
          splits on the unique years of the predictand.
        - :class:`~wass2s.was_mme.WAS_mme_xcELM`,
          :class:`~wass2s.was_mme.WAS_mme_xcELR` — xcast-based models that
          split on the ``S`` dimension.
        - :class:`~wass2s.was_mme.WAS_mme_logistic`,
          :class:`~wass2s.was_mme.WAS_mme_gaussian_process` — logistic /
          GP models that operate on tercile class labels.
        - :class:`~wass2s.was_linear_models.WAS_LogisticRegression_Model`,
          :class:`~wass2s.was_linear_models.WAS_PoissonRegression` — and
          their :class:`~wass2s.was_pcr.WAS_PCR` wrappers.
        - MLP / ELM / stacking ensembles (``same_kind_model2``) — require
          standardized predictor and predictand.
        - Tree-based ensembles — XGBoost / RF (``same_kind_model3``) — raw
          predictor, no standardization.
        - Linear regression family (``same_kind_model1``) and ML models
          (``same_kind_model1_1``) — and their PCR wrappers — with
          predictand standardization and optional ``y_test`` forwarding.

        Parameters
        ----------
        model : object
            Instantiated WAS model.
        Predictant : xarray.DataArray
            Observed predictand with a ``T`` dimension; may also have ``M``,
            ``Y``, and ``X`` dimensions.
        Predictor : xarray.DataArray, optional
            Predictor field with a ``T`` (or ``S``) dimension.  Not required
            for :class:`~wass2s.was_analog.WAS_Analog`.
        clim_year_start : int or str, optional
            First year of the climatological reference period.
        clim_year_end : int or str, optional
            Last year of the climatological reference period.
        **model_params
            Additional keyword arguments forwarded to
            ``model.compute_model`` and ``model.compute_prob``.

        Returns
        -------
        hindcast_det : xarray.DataArray
            Concatenated deterministic hindcast across all folds, with
            dimensions ``(T, Y, X)`` or ``(probability, T, Y, X)`` for
            logistic-type models.
        hindcast_prob : xarray.DataArray
            Tercile probability hindcast with dimensions
            ``(probability, T, Y, X)`` where ``probability`` ∈
            ``['PB', 'PN', 'PA']``.  Equal to *hindcast_det* for
            ELR models that directly return probabilities.
        """
        hindcast_det = []
        hindcast_prob = []
        n_splits = len(Predictant.get_index("T"))

        same_kind_model1 = [
            WAS_LinearRegression_Model, WAS_MARS_Model,
            WAS_PolynomialRegression, WAS_Ridge_Model, WAS_Lasso_Model,
            WAS_LassoLars_Model, WAS_ElasticNet_Model,
        ]

        same_kind_model1_1 = [
            WAS_SVR, WAS_RandomForest_XGBoost_ML_Stacking,
            WAS_MLP, WAS_Stacking_Ridge,
            WAS_RandomForest_XGBoost_Stacking_MLP,
        ]

        same_kind_model2 = [
            WAS_mme_MLP, WAS_mme_hpELM, WAS_mme_MLP_, WAS_mme_hpELM_,
            WAS_mme_Stacking_, WAS_mme_Stacking,
        ]

        same_kind_model3 = [
            WAS_mme_XGBoosting, WAS_mme_RF,
            WAS_mme_XGBoosting_, WAS_mme_RF_,
        ]

        if isinstance(model, WAS_CCA):
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())
            Predictor_ = (Predictor - trend_data(Predictor)
                          .fillna(trend_data(Predictor)[-3])).fillna(0)
            Predictant_st = standardize_timeseries(Predictant, clim_year_start, clim_year_end)
            Predictant_ = (Predictant_st - trend_data(Predictant_st)
                           .fillna(trend_data(Predictant_st)[-3])).fillna(0)

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor_["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor_.isel(T=train_index), Predictor_.isel(T=test_index)
                X_test_ = Predictor.isel(T=test_index)
                y_train, y_test = Predictant_.isel(T=train_index), Predictant_.isel(T=test_index)
                pred_det = model.compute_model(X_train, y_train, X_test_, y_test, **params_models)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant_["T"]
            hindcast_det = reverse_standardize(hindcast_det, Predictant, clim_year_start, clim_year_end)
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return (xr.where(hindcast_det < 0, 0, hindcast_det) * mask,
                    xr.where(hindcast_prob < 0, 0, hindcast_prob) * mask)

        elif isinstance(model, WAS_Analog):
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(
                    np.unique(Predictant["T"].dt.year), self.nb_omit), total=n_splits), start=1
            ):
                pred_det = model.compute_model(Predictant, train_index, test_index)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return hindcast_det, hindcast_prob

        elif isinstance(model, WAS_mme_xcELM):
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["S"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor.isel(S=train_index), Predictor.isel(S=test_index)
                y_train = Predictant.isel(T=train_index)
                pred_det = model.compute_model(X_train, y_train, X_test)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return hindcast_det.load(), hindcast_prob.load()

        elif isinstance(model, WAS_mme_xcELR):
            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["S"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor.isel(S=train_index), Predictor.isel(S=test_index)
                y_train = Predictant.isel(T=train_index)
                pred_det = model.compute_model(X_train, y_train, X_test)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hd = hindcast_det.load()
            return hd, hd

        elif isinstance(model, WAS_mme_logistic):
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())
            if "M" in Predictant.coords:
                Predictant = Predictant.isel(M=0).drop_vars("M").squeeze()
            Predictor["T"] = Predictant["T"]

            verify = WAS_Verification()
            Predictant_class = verify.compute_class(Predictant, clim_year_start, clim_year_end)
            Predictor_st = standardize_timeseries(Predictor, clim_year_start, clim_year_end)

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor_st.isel(T=train_index), Predictor_st.isel(T=test_index)
                y_train = Predictant_class.isel(T=train_index)
                y_test = Predictant.isel(T=test_index)
                pred_det, pred_prob = model.compute_model(
                    X_train, y_train, X_test, y_test, clim_year_start, clim_year_end, **model_params
                )
                hindcast_det.append(pred_det)
                hindcast_prob.append(pred_prob)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_prob = xr.concat(hindcast_prob, dim="T")
            hindcast_prob["T"] = Predictant["T"]
            return hindcast_det, hindcast_prob

        elif isinstance(model, WAS_mme_gaussian_process):
            if "M" in Predictant.coords:
                Predictant = Predictant.isel(M=0).drop_vars("M").squeeze()
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())
            Predictor["T"] = Predictant["T"]

            verify = WAS_Verification()
            Predictant_class = verify.compute_class(Predictant, clim_year_start, clim_year_end)
            Predictor_st = standardize_timeseries(Predictor, clim_year_start, clim_year_end)

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor_st.isel(T=train_index), Predictor_st.isel(T=test_index)
                y_train = Predictant_class.isel(T=train_index)
                y_test = Predictant.isel(T=test_index)
                pred_det, pred_prob = model.compute_model(
                    X_train, y_train, X_test, y_test, clim_year_start, clim_year_end, **model_params
                )
                hindcast_det.append(pred_det)
                hindcast_prob.append(pred_prob)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_prob = xr.concat(hindcast_prob, dim="T")
            hindcast_prob["T"] = Predictant["T"]
            return hindcast_det, hindcast_prob

        elif isinstance(model, WAS_LogisticRegression_Model) or (
            isinstance(model, WAS_PCR)
            and isinstance(model.__dict__["reg_model"], WAS_LogisticRegression_Model)
        ):
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())
            if "M" in Predictant.coords:
                Predictant = Predictant.isel(M=0).drop_vars("M").squeeze()

            verify = WAS_Verification()
            Predictant_class = verify.compute_class(Predictant, clim_year_start, clim_year_end)

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train = Predictor.isel(T=train_index)
                X_test = Predictor.isel(T=test_index)
                y_train = Predictant_class.isel(T=train_index)
                y_test = Predictant.isel(T=test_index)
                pred_prob = model.compute_model(
                    X_train, y_train, X_test, y_test, clim_year_start, clim_year_end, **model_params
                )
                hindcast_prob.append(pred_prob)

            hindcast_prob = xr.concat(hindcast_prob, dim="T")
            hindcast_prob["T"] = Predictant["T"]
            return hindcast_prob, hindcast_prob

        elif isinstance(model, WAS_PoissonRegression) or (
            isinstance(model, WAS_PCR)
            and isinstance(model.__dict__["reg_model"], WAS_PoissonRegression)
        ):
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor.isel(T=train_index), Predictor.isel(T=test_index)
                y_train, y_test = Predictant.isel(T=train_index), Predictant.isel(T=test_index)
                pred_det = model.compute_model(X_train, y_train, X_test, y_test, **params_models)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_det = hindcast_det * mask
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return hindcast_det * mask, hindcast_prob * mask

        elif any(isinstance(model, i) for i in same_kind_model2):
            if "M" in Predictant.coords:
                Predictant = Predictant.isel(M=0).drop_vars("M").squeeze()
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())
            Predictor["T"] = Predictant["T"]
            Predictor_st = standardize_timeseries(Predictor, clim_year_start, clim_year_end)
            Predictant_st = standardize_timeseries(Predictant, clim_year_start, clim_year_end)

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor_st["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor_st.isel(T=train_index), Predictor.isel(T=test_index)
                y_train, y_test = Predictant_st.isel(T=train_index), Predictant_st.isel(T=test_index)
                pred_det = model.compute_model(X_train, y_train, X_test, y_test, **params_models)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_det = hindcast_det * mask
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return hindcast_det * mask, hindcast_prob * mask

        elif any(isinstance(model, i) for i in same_kind_model3):
            if "M" in Predictant.coords:
                Predictant = Predictant.isel(M=0).drop_vars("M").squeeze()
            all_params = {**model_params}
            params_prob = {k: v for k, v in all_params.items()
                           if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())
            Predictor["T"] = Predictant["T"]

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor.isel(T=train_index), Predictor.isel(T=test_index)
                y_train, y_test = Predictant.isel(T=train_index), Predictant.isel(T=test_index)
                pred_det = model.compute_model(X_train, y_train, X_test, y_test, **params_models)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_det = hindcast_det * mask
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return hindcast_det * mask, hindcast_prob * mask

        elif any(isinstance(model, i) for i in same_kind_model1_1) or (
            isinstance(model, WAS_PCR)
            and any(isinstance(model.__dict__["reg_model"], i) for i in same_kind_model1_1)
        ):
            all_params = {**model_params}
            if isinstance(model, WAS_PCR):
                params_prob = {k: v for k, v in all_params.items()
                               if k not in model.__dict__["reg_model"].compute_model.__code__.co_varnames}
            else:
                params_prob = {k: v for k, v in all_params.items()
                               if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor.isel(T=train_index), Predictor.isel(T=test_index)
                y_train, y_test = Predictant.isel(T=train_index), Predictant.isel(T=test_index)
                pred_det = model.compute_model(X_train, y_train, X_test, y_test, **params_models)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_det = hindcast_det * mask
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return hindcast_det * mask, hindcast_prob * mask

        elif any(isinstance(model, i) for i in same_kind_model1) or (
            isinstance(model, WAS_PCR)
            and any(isinstance(model.__dict__["reg_model"], i) for i in same_kind_model1)
        ):
            all_params = {**model_params}
            if isinstance(model, WAS_PCR):
                params_prob = {k: v for k, v in all_params.items()
                               if k not in model.__dict__["reg_model"].compute_model.__code__.co_varnames}
            else:
                params_prob = {k: v for k, v in all_params.items()
                               if k not in model.compute_model.__code__.co_varnames}
            params_models = {k: v for k, v in all_params.items()
                             if k not in params_prob}

            mask = (xr.where(~np.isnan(Predictant.isel(T=0)), 1, np.nan)
                    .drop_vars(["T"]).squeeze().to_numpy())
            Predictant_st = standardize_timeseries(Predictant, clim_year_start, clim_year_end)

            print("Cross-validation ongoing")
            for i, (train_index, test_index) in enumerate(
                tqdm(self.custom_cv.split(Predictor["T"], self.nb_omit), total=n_splits), start=1
            ):
                X_train, X_test = Predictor.isel(T=train_index), Predictor.isel(T=test_index)
                y_train, y_test = Predictant_st.isel(T=train_index), Predictant_st.isel(T=test_index)
                pred_det = model.compute_model(X_train, y_train, X_test, y_test, **params_models)
                hindcast_det.append(pred_det)

            hindcast_det = xr.concat(hindcast_det, dim="T")
            hindcast_det["T"] = Predictant["T"]
            hindcast_det = hindcast_det * mask
            hindcast_det = reverse_standardize(hindcast_det, Predictant, clim_year_start, clim_year_end)
            hindcast_prob = model.compute_prob(
                Predictant, clim_year_start, clim_year_end, hindcast_det, **params_prob
            )
            return hindcast_det * mask, hindcast_prob * mask

        else:
            print("not defined models for cross-validation")
